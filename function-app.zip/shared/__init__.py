# Shared modules for Azure Functions backend
